import sys
sys.path[0:0] = [""]

import datetime
import pymongo
import unittest

from mongoengine import *
from mongoengine.connection import get_db, get_connection, ConnectionError


class ConnectionTest(unittest.TestCase):


    def setUp(self):
        connect(db='mongoenginetest')
        self.db = get_db()


    def test_connect(self):
        """Ensure that the connect() method works properly.
        """
        class User(Document):
            email = EmailField(regex=r'\w+@example.com')

        # Fails regex validation
        user = User()
        user.validate()

        # Passes regex validation
        user = User(email='me@example.com')
        self.assertTrue(user.validate() is None)

if __name__ == '__main__':
    unittest.main()
